/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Practica1/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[27];
    char stringdata0[468];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(4, 58, 12), // "GraficarTodo"
QT_MOC_LITERAL(5, 71, 12), // "MostrarGrafo"
QT_MOC_LITERAL(6, 84, 7), // "consola"
QT_MOC_LITERAL(7, 92, 13), // "GraficarTodo2"
QT_MOC_LITERAL(8, 106, 11), // "Avionllenar"
QT_MOC_LITERAL(9, 118, 54), // "AvionQuitarTurnos_llenarColaE..."
QT_MOC_LITERAL(10, 173, 15), // "GrafoDobleAvion"
QT_MOC_LITERAL(11, 189, 6), // "string"
QT_MOC_LITERAL(12, 196, 15), // "Pasajerosllenar"
QT_MOC_LITERAL(13, 212, 18), // "GrafoColaPasajeros"
QT_MOC_LITERAL(14, 231, 24), // "AvionMantenimientollenar"
QT_MOC_LITERAL(15, 256, 14), // "GrafoColaAvion"
QT_MOC_LITERAL(16, 271, 21), // "AvionMantenimientodel"
QT_MOC_LITERAL(17, 293, 13), // "Maletasllenar"
QT_MOC_LITERAL(18, 307, 9), // "noMaletas"
QT_MOC_LITERAL(19, 317, 17), // "GrafolistaMaletas"
QT_MOC_LITERAL(20, 335, 19), // "AvionEstacionllenar"
QT_MOC_LITERAL(21, 355, 13), // "Mantenimiento"
QT_MOC_LITERAL(22, 369, 21), // "GrafoEstacionServicio"
QT_MOC_LITERAL(23, 391, 17), // "EscritoriosLLenar"
QT_MOC_LITERAL(24, 409, 11), // "Escritorios"
QT_MOC_LITERAL(25, 421, 24), // "GrafoEstacionEscritorios"
QT_MOC_LITERAL(26, 446, 21) // "llenarcolaEscritorios"

    },
    "MainWindow\0on_pushButton_clicked\0\0"
    "on_pushButton_2_clicked\0GraficarTodo\0"
    "MostrarGrafo\0consola\0GraficarTodo2\0"
    "Avionllenar\0"
    "AvionQuitarTurnos_llenarColaEspera_llenarColaPasajeros\0"
    "GrafoDobleAvion\0string\0Pasajerosllenar\0"
    "GrafoColaPasajeros\0AvionMantenimientollenar\0"
    "GrafoColaAvion\0AvionMantenimientodel\0"
    "Maletasllenar\0noMaletas\0GrafolistaMaletas\0"
    "AvionEstacionllenar\0Mantenimiento\0"
    "GrafoEstacionServicio\0EscritoriosLLenar\0"
    "Escritorios\0GrafoEstacionEscritorios\0"
    "llenarcolaEscritorios"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  119,    2, 0x08 /* Private */,
       3,    0,  120,    2, 0x08 /* Private */,
       4,    0,  121,    2, 0x08 /* Private */,
       5,    0,  122,    2, 0x08 /* Private */,
       6,    0,  123,    2, 0x08 /* Private */,
       7,    0,  124,    2, 0x08 /* Private */,
       8,    0,  125,    2, 0x08 /* Private */,
       9,    0,  126,    2, 0x08 /* Private */,
      10,    0,  127,    2, 0x08 /* Private */,
      12,    0,  128,    2, 0x08 /* Private */,
      13,    0,  129,    2, 0x08 /* Private */,
      14,    0,  130,    2, 0x08 /* Private */,
      15,    0,  131,    2, 0x08 /* Private */,
      16,    0,  132,    2, 0x08 /* Private */,
      17,    1,  133,    2, 0x08 /* Private */,
      19,    0,  136,    2, 0x08 /* Private */,
      20,    1,  137,    2, 0x08 /* Private */,
      22,    0,  140,    2, 0x08 /* Private */,
      23,    1,  141,    2, 0x08 /* Private */,
      25,    0,  144,    2, 0x08 /* Private */,
      26,    0,  145,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 11,
    QMetaType::Void,
    0x80000000 | 11,
    QMetaType::Void,
    0x80000000 | 11,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   18,
    0x80000000 | 11,
    QMetaType::Void, QMetaType::Int,   21,
    0x80000000 | 11,
    QMetaType::Void, QMetaType::Int,   24,
    0x80000000 | 11,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_clicked(); break;
        case 1: _t->on_pushButton_2_clicked(); break;
        case 2: _t->GraficarTodo(); break;
        case 3: _t->MostrarGrafo(); break;
        case 4: _t->consola(); break;
        case 5: _t->GraficarTodo2(); break;
        case 6: _t->Avionllenar(); break;
        case 7: _t->AvionQuitarTurnos_llenarColaEspera_llenarColaPasajeros(); break;
        case 8: { string _r = _t->GrafoDobleAvion();
            if (_a[0]) *reinterpret_cast< string*>(_a[0]) = std::move(_r); }  break;
        case 9: _t->Pasajerosllenar(); break;
        case 10: { string _r = _t->GrafoColaPasajeros();
            if (_a[0]) *reinterpret_cast< string*>(_a[0]) = std::move(_r); }  break;
        case 11: _t->AvionMantenimientollenar(); break;
        case 12: { string _r = _t->GrafoColaAvion();
            if (_a[0]) *reinterpret_cast< string*>(_a[0]) = std::move(_r); }  break;
        case 13: _t->AvionMantenimientodel(); break;
        case 14: _t->Maletasllenar((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: { string _r = _t->GrafolistaMaletas();
            if (_a[0]) *reinterpret_cast< string*>(_a[0]) = std::move(_r); }  break;
        case 16: _t->AvionEstacionllenar((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: { string _r = _t->GrafoEstacionServicio();
            if (_a[0]) *reinterpret_cast< string*>(_a[0]) = std::move(_r); }  break;
        case 18: _t->EscritoriosLLenar((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: { string _r = _t->GrafoEstacionEscritorios();
            if (_a[0]) *reinterpret_cast< string*>(_a[0]) = std::move(_r); }  break;
        case 20: _t->llenarcolaEscritorios(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
